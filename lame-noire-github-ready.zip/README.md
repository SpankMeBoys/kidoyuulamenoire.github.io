# La Lame Noire de l’Ordre des Pourfendeurs

Page web RP prête à être hébergée gratuitement avec **GitHub Pages**.

## Mise en ligne sur GitHub Pages

1. Crée un nouveau dépôt GitHub.
2. Ajoute le fichier `index.html` à la racine du dépôt.
3. Ouvre **Settings > Pages**.
4. Dans **Build and deployment**, sélectionne :
   - Source : `Deploy from a branch`
   - Branch : `main`
   - Folder : `/ (root)`
5. Enregistre.

Après quelques instants, GitHub affichera l’adresse publique de ton site.

## Structure

```text
/
├── index.html
└── README.md
```

Le site ne nécessite aucune installation ni dépendance.
